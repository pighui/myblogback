from django.contrib.auth.hashers import make_password, check_password
from django.core.cache import cache,caches
from django.core.mail import send_mail
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect
from django.urls import reverse
from App.models import MainWheel, MainNav, MainMustBuy, MainShop, MainShow, FoodType, Goods, AXFUser, Cart, Order, \
    OrderDetail
from App.views_constant import ALL_TYPE, ORDER_TOTAL, ORDER_PRICE_UP, ORDER_PRICE_DOWN, ORDER_SALE_UP, ORDER_SALE_DOWN, \
    ORDER_STATUS_NOT_SEND, ORDER_STATUS_NOT_PAY, ORDER_STATUS_NOT_RECEIVE
import uuid

from App.views_helper import send_email_activate, total_price
from GPAXF.settings import MEDIA_KEY_PREFIX


def home(request):
    main_wheels = MainWheel.objects.all()
    main_navs = MainNav.objects.all()
    main_mustbuys = MainMustBuy.objects.all()
    main_shops = MainShop.objects.all()
    main_shop0_1 = main_shops[0:1]
    main_shop1_3 = main_shops[1:3]
    main_shop3_7 = main_shops[3:7]
    main_shop7_11 = main_shops[7:11]
    main_shows = MainShow.objects.all()
    title = "首页"
    return render(request,"main/home.html",locals())


def market(request):
    return redirect(reverse("axf:market_with_params",
                            kwargs={"typeid": "104749", "childcid": "0", "order_rule": "0"}))


def market_with_params(request, typeid, childcid, order_rule):
    foodtypes = FoodType.objects.all()

    foodtype_childname_list = [x.split(":") for x in FoodType.objects.get(typeid=typeid).childtypenames.split("#")]

    goods_list = Goods.objects.filter(categoryid = typeid)  #通过大类型的id查询对应的商品

    if childcid == ALL_TYPE:
        pass
    else:
        goods_list = goods_list.filter(childcid = childcid)

    if order_rule == ORDER_TOTAL:
        pass
    elif order_rule == ORDER_PRICE_UP:
        goods_list = goods_list.order_by("price")
    elif order_rule == ORDER_PRICE_DOWN:
        goods_list = goods_list.order_by("-price")
    elif order_rule == ORDER_SALE_UP:
        goods_list = goods_list.order_by("productnum")
    elif order_rule == ORDER_PRICE_DOWN:
        goods_list = goods_list.order_by("-productnum")

    order_rule_list = [
        ["综合排序",ORDER_TOTAL],
        ["价格升序",ORDER_PRICE_UP],
        ["价格降序",ORDER_PRICE_DOWN],
        ["销量升序",ORDER_SALE_UP],
        ["销量降序",ORDER_SALE_DOWN],
    ]

    user_id = request.session.get("user_id")
    if user_id:
        user = AXFUser.objects.get(pk=user_id)
        user_carts = Cart.objects.filter(user=user)
        for goods in goods_list:
            carts = user_carts.filter(goods= goods)
            if carts:
                cart = carts.first()
                goods.cart_goods_num = cart.cart_goods_num

    data = {
        "foodtypes": foodtypes,
        "typeid": int(typeid),
        "childcid": childcid,
        "goods_list": goods_list,
        "order_rule_list": order_rule_list,
        "order_rule_view":order_rule,
        "foodtype_childname_list": foodtype_childname_list,
        "title":"闪送超市",
    }
    return render(request, 'main/market.html', context=data)

def register(request):
    if request.method =="GET":
        return render(request,'user/register.html',{"title":"用户注册"})
    elif request.method == "POST":
        username =request.POST.get("username")
        email = request.POST.get("email")
        password = request.POST.get("password")
        icon = request.FILES.get("icon")
        new_user = AXFUser()
        new_user.u_username = username
        new_user.u_password = make_password(password)
        new_user.u_email = email
        new_user.u_icon = icon
        new_user.save()

        u_token = uuid.uuid4().hex
        cache.set(u_token,new_user.id,timeout=60*60*24)
        send_email_activate(new_user.u_username,new_user.u_email,u_token)
        return redirect(reverse("axf:login"))

def login(request):
    if request.method == "GET":
        error_message = request.session.get("error_message")
        data = {
            "title": "用户登录",
        }
        if error_message:
            del request.session["error_message"]
            data["error_message"] = error_message

        return render(request, 'user/login.html',data)

    elif request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        users = AXFUser.objects.filter(u_username=username)
        if users.exists():
            user = users.first()
            if check_password(password,user.u_password):
                if user.is_active:
                    request.session["user_id"] = user.id
                    return redirect(reverse("axf:mine"))
                else:
                    request.session["error_message"] = "用户未激活!"
                    return redirect(reverse("axf:login"))
            else:
                request.session["error_message"] = "密码错误!"
                return redirect(reverse("axf:login"))
        else:
            request.session["error_message"] = "用户不存在!"
            return redirect(reverse("axf:login"))

# def my_send_email(request):
#     subject = "请激活您的账户"
#     message = "点击下面的链接以激活您的账户，祝您使用愉快"
#     from_email = "18797367627@163.com"
#     recipient_list = ["17797172720@163.com",]
#     send_mail(subject=subject,message=message,from_email=from_email,recipient_list=recipient_list)
#     return HttpResponse("邮件发送成功")

def check_user(request):
    username = request.GET.get("username")
    users = AXFUser.objects.filter(u_username=username)
    data = {
        "status":200,
    }
    if users.exists():
        data["status"] = 901

    return JsonResponse(data)

def activate(request):
    u_token = request.GET.get("u_token")
    user_id = cache.get(u_token)
    if user_id:
        user = AXFUser.objects.get(pk=user_id)
        user.is_active = True
        user.save()
        return redirect(reverse("axf:login"))

    return render(request,"user/activate_fail.html")

def mine(request):
    user_id = request.session.get("user_id")
    data = {
        "is_login":False,
        "title":"我的主页"
    }
    if user_id:
        user = AXFUser.objects.get(pk=user_id)
        data["icon"] = MEDIA_KEY_PREFIX + user.u_icon.name
        data["is_login"] = True
        data["username"] = user.u_username
        data["order_not_pay"] = Order.objects.filter(o_user=user).filter(o_state = ORDER_STATUS_NOT_PAY).count()
        data["order_not_receive"] = Order.objects.filter(o_user=user).filter(o_state__in= [ORDER_STATUS_NOT_SEND,ORDER_STATUS_NOT_RECEIVE]).count()

    return render(request,"main/mine.html",data)

def logout(request):
    request.session.flush()
    return redirect(reverse("axf:mine"))

def gocart(request):
    carts = Cart.objects.filter(user=request.user)

    data ={
        "title":"购物车",
        "carts":carts,
        "total_price":total_price(carts),
    }

    return render(request,"main/cart.html",data)


def add_to_cart(request):
    goodsid = request.GET.get("goodsid")
    carts = Cart.objects.filter(user = request.user).filter(goods_id=goodsid)
    if carts:
        cart = carts.first()
        cart.cart_goods_num = cart.cart_goods_num + 1
    else:
        cart = Cart()
        cart.user = request.user
        cart.goods_id = goodsid

    cart.save()
    data = {
        "status":200,
        "c_goods_num":cart.cart_goods_num,
    }
    return JsonResponse(data)


def sub_from_cart(request):
    goodsid = request.GET.get("goodsid")
    carts = Cart.objects.filter(user=request.user).filter(goods_id=goodsid)
    cart = carts.first()

    data = {
        "status": 200,
    }

    if cart.cart_goods_num > 1:
        cart.cart_goods_num = cart.cart_goods_num -1
        data["c_goods_num"] = cart.cart_goods_num
        cart.save()
    else:
        cart.delete()
        data["c_goods_num"] = 0
    return JsonResponse(data)


def add_shopping(request):
    cartid = request.GET.get("cartid")
    cart = Cart.objects.get(pk = cartid)
    cart.cart_goods_num = cart.cart_goods_num + 1
    cart.save()

    user_id = request.session.get("user_id")
    user = AXFUser.objects.get(pk=user_id)

    carts = Cart.objects.filter(user=user)
    data = {
        "status":200,
        "total_price": total_price(carts),
        "c_goods_num":cart.cart_goods_num,
    }
    return JsonResponse(data)

def sub_shopping(request):
    cartid = request.GET.get("cartid")
    cart = Cart.objects.get(pk=cartid)
    cart.cart_goods_num = cart.cart_goods_num - 1
    cart.save()
    if cart.cart_goods_num == 0:
        cart.delete()

    user_id = request.session.get("user_id")
    user = AXFUser.objects.get(pk=user_id)

    carts = Cart.objects.filter(user=user)
    data = {
        "status": 200,
        "total_price": total_price(carts),
        "c_goods_num": cart.cart_goods_num,
    }
    return JsonResponse(data)


def cart_all_select(request):
    unselected = request.GET.get("cart_list")
    if unselected:
        unselected_list = unselected.split("#")
        for cartid in unselected_list:
            cart = Cart.objects.get(pk = cartid)
            cart.is_selected = True
            cart.save()

    user_id = request.session.get("user_id")
    user = AXFUser.objects.get(pk=user_id)

    carts = Cart.objects.filter(user=user)

    data = {
        'status': 200,
        'total_price':total_price(carts)

    }
    return JsonResponse(data)

def change_cart_state(request):
    cartid = request.GET.get("cartid")
    cart = Cart.objects.get(pk = cartid)
    cart.is_selected = not cart.is_selected
    cart.save()

    carts = Cart.objects.filter(user=request.user)
    is_all_select = True

    for c in carts:
        if not c.is_selected:
            is_all_select = False
            break

    data = {
        "status": 200,
        "c_is_select": cart.is_selected,
        "total_price": total_price(carts),
        "is_all_selsect" :is_all_select,
    }

    return JsonResponse(data)


def make_order(request):
    order = Order()
    order.o_user = request.user
    carts = Cart.objects.filter(user=request.user).filter(is_selected=True)
    order.o_price = total_price(carts)
    order.save()

    for cart in carts:
        orderdetail = OrderDetail()
        orderdetail.order = order
        orderdetail.goods = cart.goods
        orderdetail.order_goods_num = cart.cart_goods_num
        orderdetail.save()
        cart.delete()

    data = {
        "status":200,
        "order_id":order.id,
}
    return JsonResponse(data)


def order_detail(request):
    orderid = request.GET.get("orderid")
    order = Order.objects.get(pk = orderid)
    data = {
        "title":"订单详情",
        "order":order,
    }
    return render(request,"order/order_detail.html",data)


def order_not_pay(request):
    orders = Order.objects.filter(o_user=request.user).filter(o_state = ORDER_STATUS_NOT_PAY)
    data = {
        "title":"未支付订单",
        "orders": orders
    }
    return render(request, "order/order_list_not_pay.html", data)


def pay(request):
    orderid = request.GET.get("orderid")
    order = Order.objects.get(pk = orderid)
    order.o_state = ORDER_STATUS_NOT_SEND
    order.save()
    data = {
        "status":200
    }
    return JsonResponse(data)