from django.http import JsonResponse
from django.shortcuts import redirect
from django.urls import reverse

from django.utils.deprecation import MiddlewareMixin

from App.models import AXFUser

LOGIN_REQUIRED_JSON = ["/axf/addtocart/","/axf/subfromcart/","/axf/makeorder/","/axf/changecartstate/","/axf/payed/",]
LOGIN_REQUIRED = ["/axf/gocart/","/axf/orderdetail/","/axf/orderlistnotpay/"]

class LoginMiddleware(MiddlewareMixin):

    def process_request(self,request):
        if request.path in LOGIN_REQUIRED_JSON:
            user_id =request.session.get("user_id")
            if user_id:
                user = AXFUser.objects.get(pk = user_id)
                request.user = user
            else:
                data = {
                    "status":302,
                }
                request.session["error_message"] = "您还未登录，请先登录"
                return JsonResponse(data)

        if request.path in LOGIN_REQUIRED:
            user_id = request.session.get("user_id")
            if user_id:
                user = AXFUser.objects.get(pk=user_id)
                request.user = user
            else:
                request.session["error_message"] = "您还未登录，请先登录"
                return redirect(reverse("axf:login"))